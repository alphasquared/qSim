from .universal import QASMParser
from .configurable import ConfigurableParser
