
:mod:`quantumsim.photons` -- utilities for photon-induced dephasing
===================================================================

.. module:: quantumsim.photons

.. autosummary::
   :toctree: generated/

   get_dephasing
   add_waiting_gates_photons
