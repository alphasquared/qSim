
:mod:`quantumsim.sparsedm` -- representation of a state
=======================================================

.. module:: quantumsim.sparsedm

.. autosummary::
   :toctree: generated/

   SparseDM
