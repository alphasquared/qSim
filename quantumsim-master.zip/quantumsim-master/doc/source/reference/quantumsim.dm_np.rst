:mod:`quantumsim.dm_np` -- Numpy-based backend
==============================================

.. module:: quantumsim.dm_np

.. autosummary::
   :toctree: generated/

   DensityNP
